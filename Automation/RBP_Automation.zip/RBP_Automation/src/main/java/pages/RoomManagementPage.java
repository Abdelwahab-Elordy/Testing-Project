package pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class RoomManagementPage extends PageBase {

	public RoomManagementPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(id = "roomName")
	WebElement roomNameTxt;

	@FindBy(id = "type")
	WebElement typeList;

	@FindBy(id = "accessible")
	WebElement accessibleList;

	@FindBy(id = "roomPrice")
	WebElement roomPriceTxt;

	@FindBy(id = "createRoom")
	WebElement createRoomBtn;

	@FindBy(css = ".roomName, .room-listing p:first-child")
	public List<WebElement> roomNames;

	@FindBy(xpath = "//button[contains(text(),'Edit')]")
	public List<WebElement> editBtns;

	@FindBy(xpath = "//button[contains(text(),'Delete') or contains(@class,'delete')]")
	public List<WebElement> deleteBtns;

	@FindBy(xpath = "//button[contains(text(),'Update')]")
	WebElement updateBtn;

	@FindBy(css = ".alert-danger p, .alert p")
	public List<WebElement> errorMessages;

	public void userCanCreateRoom(String name, String type, String accessible, String price) {
		roomNameTxt.sendKeys(name);

		Select makeTypeList = new Select(typeList);
		makeTypeList.selectByVisibleText(type);

		Select makeAccessibleList = new Select(accessibleList);
		makeAccessibleList.selectByVisibleText(accessible);

		roomPriceTxt.sendKeys(price);

		createRoomBtn.click();
	}

	public void userCanDeleteRoom(int index) {
		deleteBtns.get(index).click();
	}

	public void userCanEditRoom(int index) {
		editBtns.get(index).click();
	}

	public void userCanUpdateRoom() {
		updateBtn.click();
	}

	public void clearAndSetPrice(String price) {
		roomPriceTxt.clear();
		roomPriceTxt.sendKeys(price);
	}
}
