package pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BookingPage extends PageBase {

	public BookingPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//button[contains(text(),'Book this room')]")
	public List<WebElement> bookRoomBtns;

	@FindBy(css = ".rbc-day-bg:not(.rbc-off-range-bg)")
	public List<WebElement> calendarDays;

	@FindBy(xpath = "//div[contains(@class,'room-booking-form')]//input[@placeholder='Firstname']")
	WebElement firstNameTxt;

	@FindBy(xpath = "//div[contains(@class,'room-booking-form')]//input[@placeholder='Lastname']")
	WebElement lastNameTxt;

	@FindBy(xpath = "//div[contains(@class,'room-booking-form')]//input[@placeholder='Email']")
	WebElement emailTxt;

	@FindBy(xpath = "//div[contains(@class,'room-booking-form')]//input[@placeholder='Phone']")
	WebElement phoneTxt;

	@FindBy(xpath = "//button[text()='Book' or text()='Confirm']")
	WebElement bookBtn;

	@FindBy(xpath = "//button[text()='Cancel']")
	public WebElement cancelBtn;

	@FindBy(xpath = "//*[contains(text(),'Booking Successful') or contains(text(),'Congratulations')]")
	public WebElement successMessage;

	@FindBy(css = ".alert-danger p, .alert p, .error")
	public List<WebElement> errorMessages;

	public void userCanFillBookingForm(String firstName, String lastName, String email, String phone) {
		firstNameTxt.sendKeys(firstName);
		lastNameTxt.sendKeys(lastName);
		emailTxt.sendKeys(email);
		phoneTxt.sendKeys(phone);
	}

	public void userCanSubmitBooking() {
		bookBtn.click();
	}

	public void userCanClickBookRoom(int index) {
		bookRoomBtns.get(index).click();
	}

	public void userCanSelectDates(WebDriver driver, int startIndex, int nights) {
		WebElement startDay = calendarDays.get(startIndex);
		WebElement endDay   = calendarDays.get(startIndex + nights);

		int xDiff = endDay.getLocation().getX() - startDay.getLocation().getX();
		int yDiff = endDay.getLocation().getY() - startDay.getLocation().getY();

		new org.openqa.selenium.interactions.Actions(driver)
			.clickAndHold(startDay)
			.moveByOffset(xDiff, yDiff)
			.release()
			.perform();
	}
}
