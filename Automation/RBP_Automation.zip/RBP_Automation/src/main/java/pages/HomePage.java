package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends PageBase {

	public HomePage(WebDriver driver) {
		super(driver);
	}

	@FindBy(css = "a[href*='admin'], a[href='/admin']")
	public WebElement adminPanelBtn;

	@FindBy(css = ".hotel-logo h2, .navbar-brand")
	public WebElement hotelName;

	@FindBy(css = "#contact, .contact")
	public WebElement contactSection;

	@FindBy(css = ".hotel-room-info, .room-details")
	public WebElement firstRoom;

	public void openAdminPanel() {
		adminPanelBtn.click();
	}

	public void scrollToContact(WebDriver driver) {
		((org.openqa.selenium.JavascriptExecutor) driver)
			.executeScript("arguments[0].scrollIntoView(true);", contactSection);
	}
}
