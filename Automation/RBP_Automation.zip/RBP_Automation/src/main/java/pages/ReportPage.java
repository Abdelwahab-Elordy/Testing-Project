package pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ReportPage extends PageBase {

	public ReportPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(css = ".rbc-calendar, .report-calendar")
	public WebElement calendarView;

	@FindBy(css = ".rbc-event, .booking-block")
	public List<WebElement> bookingBlocks;

	@FindBy(css = ".rbc-toolbar-label, .report-month-label")
	public WebElement currentMonthLabel;

	@FindBy(xpath = "//button[contains(@class,'back') or contains(text(),'Back')]")
	WebElement prevMonthBtn;

	@FindBy(xpath = "//button[contains(@class,'next') or contains(text(),'Next')]")
	WebElement nextMonthBtn;

	public void goToPreviousMonth() {
		prevMonthBtn.click();
	}

	public void goToNextMonth() {
		nextMonthBtn.click();
	}
}
