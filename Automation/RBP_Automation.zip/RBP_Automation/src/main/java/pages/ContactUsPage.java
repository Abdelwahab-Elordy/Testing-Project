package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ContactUsPage extends PageBase {

	public ContactUsPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(id = "name")
	WebElement nameTxt;

	@FindBy(id = "email")
	WebElement emailTxt;

	@FindBy(id = "phone")
	WebElement phoneTxt;

	@FindBy(id = "subject")
	WebElement subjectTxt;

	@FindBy(id = "description")
	WebElement messageTxt;

	@FindBy(css = "#submitContact, button[data-target='#contactModal']")
	WebElement submitBtn;

	@FindBy(xpath = "//*[contains(text(),'Thanks for getting in touch')]")
	public WebElement successMessage;

	@FindBy(xpath = "//*[contains(text(),'GET IN TOUCH') or contains(text(),'Contact')]")
	public WebElement contactUsMessage;

	@FindBy(css = ".alert-danger p, .alert p")
	public WebElement errorMessage;

	public void userCanContactUs(String name, String email, String phone, String subject, String message) {
		nameTxt.sendKeys(name);
		emailTxt.sendKeys(email);
		phoneTxt.sendKeys(phone);
		subjectTxt.sendKeys(subject);
		messageTxt.sendKeys(message);
		submitBtn.click();
	}
}
