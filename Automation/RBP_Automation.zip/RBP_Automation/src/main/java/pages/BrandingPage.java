package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BrandingPage extends PageBase {

	public BrandingPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(css = "#hotelName, input[name='name']")
	WebElement hotelNameTxt;

	@FindBy(css = "#logoUrl, input[name='logoUrl']")
	WebElement logoUrlTxt;

	@FindBy(css = "#description, textarea[name='description']")
	WebElement descriptionTxt;

	@FindBy(css = "#contactPhone, input[name='contactPhone']")
	WebElement contactPhoneTxt;

	@FindBy(css = "#contactEmail, input[name='contactEmail']")
	WebElement contactEmailTxt;

	@FindBy(xpath = "//button[contains(text(),'Update') or contains(text(),'Save')]")
	WebElement updateBtn;

	@FindBy(css = ".alert-success")
	public WebElement successMessage;

	@FindBy(css = ".alert-danger p")
	public WebElement errorMessage;

	public void userCanUpdateBranding(String hotelName, String logoUrl, String description,
			String phone, String email) {
		hotelNameTxt.clear();
		hotelNameTxt.sendKeys(hotelName);

		if (logoUrl != null) {
			logoUrlTxt.clear();
			logoUrlTxt.sendKeys(logoUrl);
		}
		if (description != null) {
			descriptionTxt.clear();
			descriptionTxt.sendKeys(description);
		}
		if (phone != null) {
			contactPhoneTxt.clear();
			contactPhoneTxt.sendKeys(phone);
		}
		if (email != null) {
			contactEmailTxt.clear();
			contactEmailTxt.sendKeys(email);
		}

		updateBtn.click();
	}
}
