package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AdminLoginPage extends PageBase {

	public AdminLoginPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(id = "username")
	WebElement usernameTxt;

	@FindBy(id = "password")
	WebElement passwordTxt;

	@FindBy(id = "doLogin")
	WebElement loginBtn;

	@FindBy(css = ".alert-danger, p.text-danger")
	public WebElement errorMessage;

	@FindBy(xpath = "//button[contains(text(),'Logout')]")
	public WebElement logoutBtn;

	@FindBy(css = ".navbar-brand, h2")
	public WebElement dashboardHeading;

	public void userCanLogin(String username, String password) {
		usernameTxt.sendKeys(username);
		passwordTxt.sendKeys(password);
		loginBtn.click();
	}

	public void userCanLogout() {
		logoutBtn.click();
	}
}
