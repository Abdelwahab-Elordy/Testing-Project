package data;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class LoadRoomHappyAndNegativeDataExcel {
	FileInputStream stream = null;
	
	public FileInputStream getExcelFile() {
		String filePath = System.getProperty("user.dir") + "\\src\\test\\java\\ExcelFiles\\RoomData.xlsx";
		
		File roomFile = new File(filePath);
		
		try {
			stream = new FileInputStream(roomFile);
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found");
		}
		
		return stream;
	}
	
	public Object[][] getExcelRoomData() throws IOException {
		stream = getExcelFile();
		
		XSSFWorkbook workBook = new XSSFWorkbook(stream);
		XSSFSheet roomSheet = workBook.getSheetAt(0);
		
		int nRows = roomSheet.getLastRowNum() + 1;
		int nCols = 4;
		
		Object[][] roomData = new Object[nRows][nCols];
		
		for (int i = 0; i < nRows; ++i) {
			XSSFRow row = roomSheet.getRow(i);
			
			for (int j = 0; j < nCols; ++j) {
				roomData[i][j] = row.getCell(j).toString();
			}
		}
		
		return roomData;
	}
}
