package data;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class LoadBrowserSetup {
	public static Properties browserData = getBrowserData(System.getProperty("user.dir")+ "\\src\\test\\java\\PropertiesFiles\\browserSetup.properties");
	
	private static Properties getBrowserData(String filePath) {
		Properties pro = new Properties();
		
		try {
			FileInputStream stream = new FileInputStream(filePath);
			try {
				pro.load(stream);
			} catch (IOException e) {
				System.out.println("Cannot Read Data from the file");
			}
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found");
		}
		
		return pro;
	}
}
