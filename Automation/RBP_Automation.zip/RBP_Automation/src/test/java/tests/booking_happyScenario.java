package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.AdminLoginPage;
import pages.BookingPage;
import pages.RoomManagementPage;

public class booking_happyScenario extends TestBase {
	AdminLoginPage adminLoginObject;
	RoomManagementPage roomObject;
	BookingPage bookingObject;

	public void initializeObjects() {
		adminLoginObject = new AdminLoginPage(driver);
		roomObject = new RoomManagementPage(driver);
		bookingObject = new BookingPage(driver);
	}

	@Test(priority = 1)
	public void testBooking_ValidMandatoryFields_SuccessMessageDisplayed() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(adminURL);
		Thread.sleep(2000);
		adminLoginObject.userCanLogin("admin", "password");
		Thread.sleep(2000);
		roomObject.userCanCreateRoom("BookRoom101", "Single", "true", "99");
		Thread.sleep(2000);

		driver.navigate().to(baseURL);
		Thread.sleep(3000);

		bookingObject.userCanClickBookRoom(0);
		Thread.sleep(1000);

		bookingObject.userCanSelectDates(driver, 5, 2);
		Thread.sleep(1000);

		bookingObject.userCanFillBookingForm("Ahmed", "Mohamed", "ahmed@test.com", "01234567891");

		bookingObject.userCanSubmitBooking();
		Thread.sleep(3000);

		Assert.assertTrue(bookingObject.successMessage.isDisplayed(),
				"Booking success message should be displayed after valid submission");
	}

	@Test(priority = 2, dependsOnMethods = {"testBooking_ValidMandatoryFields_SuccessMessageDisplayed"})
	public void testBooking_NoLoginRequired() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(baseURL);
		Thread.sleep(3000);

		Assert.assertFalse(bookingObject.bookRoomBtns.isEmpty(),
				"Book room buttons should be visible to guests without login");
	}
}
