package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.AdminLoginPage;
import pages.HomePage;

public class adminLogin_happyScenario extends TestBase {
	HomePage homeObject;
	AdminLoginPage adminLoginObject;

	public void initializeObjects() {
		homeObject = new HomePage(driver);
		adminLoginObject = new AdminLoginPage(driver);
	}

	@Test(priority = 1)
	public void testLogin_ValidUsernameAndMatchingPassword() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin("admin", "password");
		Thread.sleep(2000);

		Assert.assertTrue(adminLoginObject.logoutBtn.isEnabled());

		adminLoginObject.userCanLogout();
	}

	@Test(priority = 2, dependsOnMethods = {"testLogin_ValidUsernameAndMatchingPassword"})
	public void testLogin_SessionPersists_AfterNavigation() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin("admin", "password");
		Thread.sleep(2000);

		Assert.assertTrue(driver.getCurrentUrl().contains("admin"));

		adminLoginObject.userCanLogout();
	}

	@Test(priority = 3, dependsOnMethods = {"testLogin_SessionPersists_AfterNavigation"})
	public void testLogout_BackButtonDoesNotRestoreSession() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin("admin", "password");
		Thread.sleep(2000);

		adminLoginObject.userCanLogout();
		Thread.sleep(1000);

		driver.navigate().back();
		Thread.sleep(2000);

		Assert.assertFalse(driver.getCurrentUrl().contains("#rooms"),
				"Back button must not restore admin session after logout");
	}
}
