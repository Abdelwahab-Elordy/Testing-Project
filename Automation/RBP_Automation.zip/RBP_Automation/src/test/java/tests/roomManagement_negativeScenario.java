package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.AdminLoginPage;
import pages.RoomManagementPage;

public class roomManagement_negativeScenario extends TestBase {
	AdminLoginPage adminLoginObject;
	RoomManagementPage roomObject;

	public void initializeObjects() {
		adminLoginObject = new AdminLoginPage(driver);
		roomObject = new RoomManagementPage(driver);
	}

	@Test(priority = 1)
	public void testRoom_CreateRoomWithBlankName() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin("admin", "password");
		Thread.sleep(2000);

		roomObject.userCanCreateRoom("", "Single", "true", "100");
		Thread.sleep(2000);

		Assert.assertFalse(roomObject.errorMessages.isEmpty(),
				"Error should appear when room name is blank");
	}

	@Test(priority = 2, dependsOnMethods = {"testRoom_CreateRoomWithBlankName"})
	public void testRoom_CreateRoomWithBlankPrice() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin("admin", "password");
		Thread.sleep(2000);

		roomObject.userCanCreateRoom("ValidRoom", "Single", "true", "");
		Thread.sleep(2000);

		Assert.assertFalse(roomObject.errorMessages.isEmpty(),
				"Error should appear when price is blank");
	}

	@Test(priority = 3, dependsOnMethods = {"testRoom_CreateRoomWithBlankPrice"})
	public void testRoom_CreateRoomWithNegativePrice() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin("admin", "password");
		Thread.sleep(2000);

		roomObject.userCanCreateRoom("ValidRoom", "Double", "false", "-50");
		Thread.sleep(2000);

		Assert.assertFalse(roomObject.errorMessages.isEmpty(),
				"Error should appear for negative price");
	}

	@Test(priority = 4, dependsOnMethods = {"testRoom_CreateRoomWithNegativePrice"})
	public void testRoom_CreateRoomWithZeroPrice() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin("admin", "password");
		Thread.sleep(2000);

		roomObject.userCanCreateRoom("ValidRoom", "Twin", "false", "0");
		Thread.sleep(2000);

		Assert.assertFalse(roomObject.errorMessages.isEmpty(),
				"Error should appear for zero price");
	}

	@Test(priority = 5, dependsOnMethods = {"testRoom_CreateRoomWithZeroPrice"})
	public void testRoom_CreateRoomWithLettersInPrice() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin("admin", "password");
		Thread.sleep(2000);

		roomObject.userCanCreateRoom("ValidRoom", "Family", "true", "abc");
		Thread.sleep(2000);

		Assert.assertFalse(roomObject.errorMessages.isEmpty(),
				"Error should appear for letters in price field");
	}
}
