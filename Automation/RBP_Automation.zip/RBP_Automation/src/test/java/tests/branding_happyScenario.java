package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.AdminLoginPage;
import pages.BrandingPage;

public class branding_happyScenario extends TestBase {
	AdminLoginPage adminLoginObject;
	BrandingPage brandingObject;

	public void initializeObjects() {
		adminLoginObject = new AdminLoginPage(driver);
		brandingObject = new BrandingPage(driver);
	}

	@Test(priority = 1)
	public void testBranding_UpdateHotelNameWithValidData() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin("admin", "password");
		Thread.sleep(2000);

		driver.navigate().to(adminURL + "#branding");
		Thread.sleep(2000);

		brandingObject.userCanUpdateBranding("Shady Meadows B&B", null, null, null, null);
		Thread.sleep(2000);

		Assert.assertFalse(brandingObject.errorMessage.isDisplayed(),
				"No error should appear for valid hotel name");
	}

	@Test(priority = 2, dependsOnMethods = {"testBranding_UpdateHotelNameWithValidData"})
	public void testBranding_UpdateContactDetailsWithValidData() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin("admin", "password");
		Thread.sleep(2000);

		driver.navigate().to(adminURL + "#branding");
		Thread.sleep(2000);

		brandingObject.userCanUpdateBranding("Shady Meadows B&B", null, null, "01234567890", "hotel@test.com");
		Thread.sleep(2000);

		Assert.assertTrue(brandingObject.successMessage.isDisplayed(),
				"Success message should appear after valid branding update");
	}
}
