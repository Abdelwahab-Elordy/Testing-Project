package tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pages.AdminLoginPage;

public class adminLogin_negativeAndhappyScenario_WithDDTAndDataProvider extends TestBase {
	AdminLoginPage adminLoginObject;

	@DataProvider(name = "LoginData")
	public Object[][] getLoginData() {
		Object[][] loginData = {
				{"admin", "password", true},
				{"admin", "wrongPassword", false},
				{"wrongUser", "password", false},
				{"wrongUser", "wrongPassword", false},
		};

		return loginData;
	}

	@Test(priority = 1, dataProvider = "LoginData")
	public void testLogin_UsernameOrPasswordIsIncorrectORUsernameAndPasswordIsCorrect(
			String username, String password, boolean isLoginSuccessful) throws InterruptedException {
		adminLoginObject = new AdminLoginPage(driver);

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin(username, password);
		Thread.sleep(2000);

		if (isLoginSuccessful) {
			Assert.assertTrue(adminLoginObject.logoutBtn.isEnabled());
			adminLoginObject.userCanLogout();
		} else {
			Assert.assertEquals(adminLoginObject.errorMessage.getText(), "Invalid credentials");
		}
	}
}
