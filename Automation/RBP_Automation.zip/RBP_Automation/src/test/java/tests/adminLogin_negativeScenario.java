package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.AdminLoginPage;

public class adminLogin_negativeScenario extends TestBase {
	AdminLoginPage adminLoginObject;

	@Test(priority = 1)
	public void testLogin_WrongPasswordAndCorrectUsername() throws InterruptedException {
		adminLoginObject = new AdminLoginPage(driver);

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin("admin", "wrongPassword");
		Thread.sleep(2000);

		Assert.assertEquals(adminLoginObject.errorMessage.getText(), "Invalid credentials");
	}

	@Test(priority = 2, dependsOnMethods = {"testLogin_WrongPasswordAndCorrectUsername"})
	public void testLogin_WrongUsernameAndCorrectPassword() throws InterruptedException {
		adminLoginObject = new AdminLoginPage(driver);

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin("wrongUser", "password");
		Thread.sleep(2000);

		Assert.assertEquals(adminLoginObject.errorMessage.getText(), "Invalid credentials");
	}

	@Test(priority = 3, dependsOnMethods = {"testLogin_WrongUsernameAndCorrectPassword"})
	public void testLogin_EmptyUsername() throws InterruptedException {
		adminLoginObject = new AdminLoginPage(driver);

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin("", "password");
		Thread.sleep(2000);

		Assert.assertTrue(driver.getCurrentUrl().contains("admin") &&
				!driver.getCurrentUrl().contains("#rooms"),
				"Form must not submit with empty username");
	}

	@Test(priority = 4, dependsOnMethods = {"testLogin_EmptyUsername"})
	public void testLogin_EmptyPassword() throws InterruptedException {
		adminLoginObject = new AdminLoginPage(driver);

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin("admin", "");
		Thread.sleep(2000);

		Assert.assertTrue(driver.getCurrentUrl().contains("admin") &&
				!driver.getCurrentUrl().contains("#rooms"),
				"Form must not submit with empty password");
	}

	@Test(priority = 5, dependsOnMethods = {"testLogin_EmptyPassword"})
	public void testLogin_UnauthenticatedAdminAccess_RedirectsToLogin() throws InterruptedException {
		adminLoginObject = new AdminLoginPage(driver);

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		Assert.assertTrue(driver.getCurrentUrl().contains("admin"),
				"Unauthenticated /admin access should stay on login page");
		Assert.assertFalse(driver.getCurrentUrl().contains("#rooms"),
				"Unauthenticated access must not reach rooms dashboard");
	}
}
