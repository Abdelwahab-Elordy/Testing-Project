package tests;

import java.awt.AWTException;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.ContactUsPage;
import pages.HomePage;

public class contactUs_happyScenario extends TestBase {
	HomePage homeObject;
	ContactUsPage contactUsObject;

	public void initializaObjects() {
		homeObject = new HomePage(driver);
		contactUsObject = new ContactUsPage(driver);
	}

	@Test
	public void testContactUs_ValidMandatoryAndOptionalFields() throws InterruptedException, AWTException {
		initializaObjects();

		Assert.assertEquals(homeObject.hotelName.getText(), "Shady Meadows B&B");

		homeObject.scrollToContact(driver);
		Thread.sleep(3000);

		Assert.assertEquals(contactUsObject.contactUsMessage.getText(), "GET IN TOUCH");

		contactUsObject.userCanContactUs(
				"Abdelrahman Osama",
				"abdelrahman@gmail.com",
				"01234567890",
				"Complain",
				"My order doesn't deliver yet! This is a long enough message.");

		Thread.sleep(3000);

		Assert.assertEquals(contactUsObject.successMessage.getText(),
				"Thanks for getting in touch Abdelrahman Osama!");
	}
}
