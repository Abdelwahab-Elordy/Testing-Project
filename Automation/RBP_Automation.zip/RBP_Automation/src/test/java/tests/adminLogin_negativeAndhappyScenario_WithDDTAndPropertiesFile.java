package tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import data.LoadContactHappyAndNegativeDataProperties;
import pages.AdminLoginPage;

public class adminLogin_negativeAndhappyScenario_WithDDTAndPropertiesFile extends TestBase {
	AdminLoginPage adminLoginObject;

	String validUsername = LoadContactHappyAndNegativeDataProperties.contactData.getProperty("adminUsername");
	String validPassword = LoadContactHappyAndNegativeDataProperties.contactData.getProperty("adminPassword");
	String invalidPassword = LoadContactHappyAndNegativeDataProperties.contactData.getProperty("adminInvalidPassword");

	@DataProvider(name = "getLoginData")
	public Object[][] getLoginData() {
		Object[][] loginData = {
				{validUsername, validPassword, true},
				{validUsername, invalidPassword, false}
		};

		return loginData;
	}

	@Test(priority = 1, dataProvider = "getLoginData")
	public void testLogin_UsernameOrPasswordIsIncorrectORUsernameAndPasswordIsCorrect(
			String username, String password, boolean isSuccessful) throws InterruptedException {
		adminLoginObject = new AdminLoginPage(driver);

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin(username, password);
		Thread.sleep(2000);

		if (isSuccessful) {
			Assert.assertTrue(adminLoginObject.logoutBtn.isEnabled());
			adminLoginObject.userCanLogout();
		} else {
			Assert.assertEquals(adminLoginObject.errorMessage.getText(), "Invalid credentials");
		}
	}
}
