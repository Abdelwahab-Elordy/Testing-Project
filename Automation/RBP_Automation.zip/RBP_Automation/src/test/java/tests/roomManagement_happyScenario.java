package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.AdminLoginPage;
import pages.RoomManagementPage;

public class roomManagement_happyScenario extends TestBase {
	AdminLoginPage adminLoginObject;
	RoomManagementPage roomObject;

	public void initializeObjects() {
		adminLoginObject = new AdminLoginPage(driver);
		roomObject = new RoomManagementPage(driver);
	}

	@Test(priority = 1)
	public void testRoom_CreateSingleRoomWithValidData() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin("admin", "password");
		Thread.sleep(2000);

		int roomsBefore = roomObject.roomNames.size();

		roomObject.userCanCreateRoom("TestRoom101", "Single", "true", "99");
		Thread.sleep(2000);

		Assert.assertTrue(roomObject.roomNames.size() > roomsBefore,
				"Room should be created and appear in the list");
	}

	@Test(priority = 2, dependsOnMethods = {"testRoom_CreateSingleRoomWithValidData"})
	public void testRoom_CreateDoubleRoomWithValidData() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin("admin", "password");
		Thread.sleep(2000);

		int roomsBefore = roomObject.roomNames.size();

		roomObject.userCanCreateRoom("TestRoom202", "Double", "false", "150");
		Thread.sleep(2000);

		Assert.assertTrue(roomObject.roomNames.size() > roomsBefore,
				"Double room should be created successfully");
	}

	@Test(priority = 3, dependsOnMethods = {"testRoom_CreateDoubleRoomWithValidData"})
	public void testRoom_CreateSuiteRoomWithValidData() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin("admin", "password");
		Thread.sleep(2000);

		int roomsBefore = roomObject.roomNames.size();

		roomObject.userCanCreateRoom("TestRoom303", "Suite", "true", "300");
		Thread.sleep(2000);

		Assert.assertTrue(roomObject.roomNames.size() > roomsBefore,
				"Suite room should be created successfully");
	}

	@Test(priority = 4, dependsOnMethods = {"testRoom_CreateSuiteRoomWithValidData"})
	public void testRoom_DeleteRoom() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin("admin", "password");
		Thread.sleep(2000);

		int roomsBefore = roomObject.roomNames.size();

		roomObject.userCanDeleteRoom(0);
		Thread.sleep(2000);

		Assert.assertTrue(roomObject.roomNames.size() < roomsBefore,
				"Room count should decrease after deletion");
	}
}
