package tests;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import data.LoadRoomHappyAndNegativeDataExcel;
import pages.AdminLoginPage;
import pages.RoomManagementPage;

public class roomManagement_negativeAndhappyScenario_WithDDTAndExcelSheet extends TestBase {
	AdminLoginPage adminLoginObject;
	RoomManagementPage roomObject;

	@DataProvider(name = "RoomData")
	public Object[][] getRoomData() throws IOException {
		LoadRoomHappyAndNegativeDataExcel roomDataObject = new LoadRoomHappyAndNegativeDataExcel();
		return roomDataObject.getExcelRoomData();
	}

	@Test(priority = 1, dataProvider = "RoomData")
	public void testRoom_CreateRoomWithValidAndInvalidData(String name, String type,
			String price, String isSuccessful) throws InterruptedException {
		adminLoginObject = new AdminLoginPage(driver);
		roomObject = new RoomManagementPage(driver);

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin("admin", "password");
		Thread.sleep(2000);

		int roomsBefore = roomObject.roomNames.size();

		roomObject.userCanCreateRoom(name, type, "true", price);
		Thread.sleep(2000);

		if (isSuccessful.equalsIgnoreCase("true")) {
			Assert.assertTrue(roomObject.roomNames.size() > roomsBefore,
					"Room should be created for valid data");
		} else {
			Assert.assertFalse(roomObject.errorMessages.isEmpty(),
					"Error should appear for invalid data");
		}
	}
}
