package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.AdminLoginPage;
import pages.ReportPage;

public class report_happyScenario extends TestBase {
	AdminLoginPage adminLoginObject;
	ReportPage reportObject;

	public void initializeObjects() {
		adminLoginObject = new AdminLoginPage(driver);
		reportObject = new ReportPage(driver);
	}

	@Test(priority = 1)
	public void testReport_CalendarIsDisplayed() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin("admin", "password");
		Thread.sleep(2000);

		driver.navigate().to(adminURL + "#report");
		Thread.sleep(2000);

		Assert.assertTrue(reportObject.calendarView.isDisplayed(),
				"Report calendar should be displayed in Admin panel");
	}

	@Test(priority = 2, dependsOnMethods = {"testReport_CalendarIsDisplayed"})
	public void testReport_MonthNavigationWorks() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(adminURL);
		Thread.sleep(2000);

		adminLoginObject.userCanLogin("admin", "password");
		Thread.sleep(2000);

		driver.navigate().to(adminURL + "#report");
		Thread.sleep(2000);

		String currentMonth = reportObject.currentMonthLabel.getText();

		reportObject.goToNextMonth();
		Thread.sleep(1000);

		Assert.assertNotEquals(reportObject.currentMonthLabel.getText(), currentMonth,
				"Month label should change after clicking Next");

		reportObject.goToPreviousMonth();
		Thread.sleep(1000);

		Assert.assertEquals(reportObject.currentMonthLabel.getText(), currentMonth,
				"Month label should return to original after clicking Prev");
	}
}
