package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.ContactUsPage;
import pages.HomePage;

public class contactUs_negativeScenario extends TestBase {
	HomePage homeObject;
	ContactUsPage contactUsObject;

	public void initializaObjects() {
		homeObject = new HomePage(driver);
		contactUsObject = new ContactUsPage(driver);
	}

	@Test(priority = 1)
	public void testContactUs_BlankName() throws InterruptedException {
		initializaObjects();

		homeObject.scrollToContact(driver);
		Thread.sleep(2000);

		contactUsObject.userCanContactUs(
				"",
				"test@test.com",
				"01234567890",
				"Valid Subject",
				"This is a valid message with more than twenty characters.");
		Thread.sleep(2000);

		Assert.assertTrue(contactUsObject.errorMessage.isDisplayed(),
				"Error should appear when name is blank");
	}

	@Test(priority = 2, dependsOnMethods = {"testContactUs_BlankName"})
	public void testContactUs_NameBelowMinimumLength() throws InterruptedException {
		initializaObjects();

		homeObject.scrollToContact(driver);
		Thread.sleep(2000);

		contactUsObject.userCanContactUs(
				"AB",
				"test@test.com",
				"01234567890",
				"Valid Subject",
				"This is a valid message with more than twenty characters.");
		Thread.sleep(2000);

		Assert.assertTrue(contactUsObject.errorMessage.isDisplayed(),
				"Error should appear when name is below 3 characters");
	}

	@Test(priority = 3, dependsOnMethods = {"testContactUs_NameBelowMinimumLength"})
	public void testContactUs_BlankEmail() throws InterruptedException {
		initializaObjects();

		homeObject.scrollToContact(driver);
		Thread.sleep(2000);

		contactUsObject.userCanContactUs(
				"TestUser",
				"",
				"01234567890",
				"Valid Subject",
				"This is a valid message with more than twenty characters.");
		Thread.sleep(2000);

		Assert.assertTrue(contactUsObject.errorMessage.isDisplayed(),
				"Error should appear when email is blank");
	}

	@Test(priority = 4, dependsOnMethods = {"testContactUs_BlankEmail"})
	public void testContactUs_InvalidEmailFormat() throws InterruptedException {
		initializaObjects();

		homeObject.scrollToContact(driver);
		Thread.sleep(2000);

		contactUsObject.userCanContactUs(
				"TestUser",
				"notAnEmail",
				"01234567890",
				"Valid Subject",
				"This is a valid message with more than twenty characters.");
		Thread.sleep(2000);

		Assert.assertTrue(contactUsObject.errorMessage.isDisplayed(),
				"Error should appear for invalid email format");
	}

	@Test(priority = 5, dependsOnMethods = {"testContactUs_InvalidEmailFormat"})
	public void testContactUs_PhoneBelowMinimumLength() throws InterruptedException {
		initializaObjects();

		homeObject.scrollToContact(driver);
		Thread.sleep(2000);

		contactUsObject.userCanContactUs(
				"TestUser",
				"test@test.com",
				"0100000000",
				"Valid Subject",
				"This is a valid message with more than twenty characters.");
		Thread.sleep(2000);

		Assert.assertTrue(contactUsObject.errorMessage.isDisplayed(),
				"Error should appear when phone is below 11 characters");
	}

	@Test(priority = 6, dependsOnMethods = {"testContactUs_PhoneBelowMinimumLength"})
	public void testContactUs_SubjectBelowMinimumLength() throws InterruptedException {
		initializaObjects();

		homeObject.scrollToContact(driver);
		Thread.sleep(2000);

		contactUsObject.userCanContactUs(
				"TestUser",
				"test@test.com",
				"01234567890",
				"Hey",
				"This is a valid message with more than twenty characters.");
		Thread.sleep(2000);

		Assert.assertTrue(contactUsObject.errorMessage.isDisplayed(),
				"Error should appear when subject is below 5 characters");
	}

	@Test(priority = 7, dependsOnMethods = {"testContactUs_SubjectBelowMinimumLength"})
	public void testContactUs_MessageBelowMinimumLength() throws InterruptedException {
		initializaObjects();

		homeObject.scrollToContact(driver);
		Thread.sleep(2000);

		contactUsObject.userCanContactUs(
				"TestUser",
				"test@test.com",
				"01234567890",
				"Valid Subject",
				"Short msg");
		Thread.sleep(2000);

		Assert.assertTrue(contactUsObject.errorMessage.isDisplayed(),
				"Error should appear when message is below 20 characters");
	}
}
