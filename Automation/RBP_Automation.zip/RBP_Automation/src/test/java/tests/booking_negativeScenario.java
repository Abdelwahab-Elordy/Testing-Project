package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.AdminLoginPage;
import pages.BookingPage;
import pages.RoomManagementPage;

public class booking_negativeScenario extends TestBase {
	AdminLoginPage adminLoginObject;
	RoomManagementPage roomObject;
	BookingPage bookingObject;

	public void initializeObjects() {
		adminLoginObject = new AdminLoginPage(driver);
		roomObject = new RoomManagementPage(driver);
		bookingObject = new BookingPage(driver);
	}

	@Test(priority = 1)
	public void testBooking_BlankFirstName() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(adminURL);
		Thread.sleep(2000);
		adminLoginObject.userCanLogin("admin", "password");
		Thread.sleep(2000);
		roomObject.userCanCreateRoom("NegRoom101", "Single", "true", "99");
		Thread.sleep(2000);

		driver.navigate().to(baseURL);
		Thread.sleep(3000);

		bookingObject.userCanClickBookRoom(0);
		Thread.sleep(1000);
		bookingObject.userCanSelectDates(driver, 5, 2);
		Thread.sleep(1000);

		bookingObject.userCanFillBookingForm("", "Mohamed", "ahmed@test.com", "01234567891");
		bookingObject.userCanSubmitBooking();
		Thread.sleep(2000);

		Assert.assertFalse(bookingObject.errorMessages.isEmpty(),
				"Error should appear when first name is blank");
	}

	@Test(priority = 2, dependsOnMethods = {"testBooking_BlankFirstName"})
	public void testBooking_FirstNameBelowMinimumLength() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(baseURL);
		Thread.sleep(3000);

		bookingObject.userCanClickBookRoom(0);
		Thread.sleep(1000);
		bookingObject.userCanSelectDates(driver, 5, 2);
		Thread.sleep(1000);

		bookingObject.userCanFillBookingForm("Ab", "Mohamed", "ahmed@test.com", "01234567891");
		bookingObject.userCanSubmitBooking();
		Thread.sleep(2000);

		Assert.assertFalse(bookingObject.errorMessages.isEmpty(),
				"Error should appear when first name is below 3 characters");
	}

	@Test(priority = 3, dependsOnMethods = {"testBooking_FirstNameBelowMinimumLength"})
	public void testBooking_BlankEmail() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(baseURL);
		Thread.sleep(3000);

		bookingObject.userCanClickBookRoom(0);
		Thread.sleep(1000);
		bookingObject.userCanSelectDates(driver, 5, 2);
		Thread.sleep(1000);

		bookingObject.userCanFillBookingForm("Ahmed", "Mohamed", "", "01234567891");
		bookingObject.userCanSubmitBooking();
		Thread.sleep(2000);

		Assert.assertFalse(bookingObject.errorMessages.isEmpty(),
				"Error should appear when email is blank");
	}

	@Test(priority = 4, dependsOnMethods = {"testBooking_BlankEmail"})
	public void testBooking_PhoneBelowMinimumLength() throws InterruptedException {
		initializeObjects();

		driver.navigate().to(baseURL);
		Thread.sleep(3000);

		bookingObject.userCanClickBookRoom(0);
		Thread.sleep(1000);
		bookingObject.userCanSelectDates(driver, 5, 2);
		Thread.sleep(1000);

		bookingObject.userCanFillBookingForm("Ahmed", "Mohamed", "ahmed@test.com", "0100000000");
		bookingObject.userCanSubmitBooking();
		Thread.sleep(2000);

		Assert.assertFalse(bookingObject.errorMessages.isEmpty(),
				"Error should appear when phone is below 11 characters");
	}
}
