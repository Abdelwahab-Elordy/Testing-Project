package tests;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;

import data.LoadBrowserSetup;
import helpers.ScreenShot;

public class TestBase {
	WebDriver driver;
	String baseURL = "https://automationintesting.online/";
	String adminURL = "https://automationintesting.online/admin";
	String browserName = LoadBrowserSetup.browserData.getProperty("browser");
	String timeout = LoadBrowserSetup.browserData.getProperty("timeout");

	@BeforeTest
	public void openWebsite() {
		if (browserName.equalsIgnoreCase("Chrome")) {
			driver = new ChromeDriver();
		}
		if (browserName.equalsIgnoreCase("FireFox")) {
			driver = new FirefoxDriver();
		}
		if (browserName.equalsIgnoreCase("edge")) {
			driver = new EdgeDriver();
		}

		driver.navigate().to(baseURL);
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Long.parseLong(timeout)));
		driver.manage().window().maximize();
	}

	@AfterMethod
	public void takeScreenShot(ITestResult result) throws IOException {
		if (result.getStatus() == ITestResult.FAILURE) {
			ScreenShot.getScreenShot(driver, result.getName());
		}
	}

	@AfterClass
	public void closeWebsite() {
		driver.quit();
	}
}
