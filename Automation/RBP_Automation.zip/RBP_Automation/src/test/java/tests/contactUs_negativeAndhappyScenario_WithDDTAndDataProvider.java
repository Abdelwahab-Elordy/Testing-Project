package tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pages.ContactUsPage;
import pages.HomePage;

public class contactUs_negativeAndhappyScenario_WithDDTAndDataProvider extends TestBase {
	HomePage homeObject;
	ContactUsPage contactUsObject;

	@DataProvider(name = "ContactData")
	public Object[][] getContactData() {
		Object[][] contactData = {
				{"Abdelrahman Osama", "abdelrahman@gmail.com", "01234567890",
						"Valid Subject Here", "This is a valid message with more than twenty characters.", true},
				{"AB", "test@test.com", "01234567890",
						"Valid Subject", "This is a valid message with more than twenty characters.", false},
				{"TestUser", "", "01234567890",
						"Valid Subject", "This is a valid message with more than twenty characters.", false},
				{"TestUser", "notAnEmail", "01234567890",
						"Valid Subject", "This is a valid message with more than twenty characters.", false},
				{"TestUser", "test@test.com", "01234567890",
						"Hey", "This is a valid message with more than twenty characters.", false},
				{"TestUser", "test@test.com", "01234567890",
						"Valid Subject", "Short msg", false},
		};

		return contactData;
	}

	@Test(priority = 1, dataProvider = "ContactData")
	public void testContactUs_ValidAndInvalidData(String name, String email, String phone,
			String subject, String message, boolean isSuccessful) throws InterruptedException {
		homeObject = new HomePage(driver);
		contactUsObject = new ContactUsPage(driver);

		homeObject.scrollToContact(driver);
		Thread.sleep(2000);

		contactUsObject.userCanContactUs(name, email, phone, subject, message);
		Thread.sleep(2000);

		if (isSuccessful) {
			Assert.assertTrue(contactUsObject.successMessage.isDisplayed(),
					"Success message should appear for valid data");
		} else {
			Assert.assertTrue(contactUsObject.errorMessage.isDisplayed(),
					"Error message should appear for invalid data");
		}
	}
}
